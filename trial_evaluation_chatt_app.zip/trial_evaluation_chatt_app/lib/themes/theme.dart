import 'package:flutter/material.dart';

ThemeData theme = ThemeData(
  colorScheme: ColorScheme.light(
    background: Colors.white,
    primary: Colors.blue.shade300,
    secondary: Colors.black,
    tertiary: Colors.red.shade100,
    inversePrimary: Colors.grey.shade700,
  )
);
